#01010011 01001111 01001100 01001001 01000100 00100000 01010011 01001110 01000001 01001011 01000101 00100000

import re,urllib,urlparse,json,base64,time

from resources.lib.modules import cleantitle
from resources.lib.modules import dom_parser2
from resources.lib.modules import client

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['movies123free.co']
        self.base_link = 'http://movies123free.co'
        self.search_link = 'http://movies123free.co/?s='
        
    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            clean_title = cleantitle.geturl(title)
            url = clean_title+'$$$$$'+year
           
            return url
        except:
            return

  
    def sources(self, url, hostDict, hostprDict):
        #try:
            sources = []
            if url == None: return sources
            data=url.split('$$$$$')
            title=data[0]
            year=data[1]
            url='http://movies123free.co/%s-%s/'%(title,year)
            r = client.request(url)
            quality = "720"
            
            regex=' title="movie-download".+?<iframe.+?src="(.+?)"'
            src=re.compile(regex,re.DOTALL).findall(r)[0]
            regex='//(.+?)/'
            host=re.compile(regex).findall(src)[0]
            sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': src, 'direct': False, 'debridonly': False})
            return sources
        #except:
        #    return sources
    def resolve(self, url):
        return url
