# coding: utf-8

############################################################

############### Credit To Gotham Scrapers ##################

############################################################

import requests,re,logging
from resources.lib.modules import cfscrape,checkerfrom resources.lib.modules import debrid as debrid_s
import xbmc,xbmcaddon

User_Agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36'

# =======================================================================================================================================
def clean_title(title):    if title is None:        return    try:        title = title.encode('utf-8')    except:        pass    title = re.sub('&#(\d+);', '', title)    title = re.sub('(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)    title = title.replace('&quot;', '\"').replace('&amp;', '&')    title = re.sub('\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|(:|;|-|–|"|,|\_|\.|\?)|\s', '', title).lower()    return title    def clean_search(title):    if title == None: return    title = title.lower()    title = re.sub('&#(\d+);', '', title)    title = re.sub('(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)    title = title.replace('&quot;', '\"').replace('&amp;', '&')    title = re.sub('\\\|/|\(|\)|\[|\]|\{|\}|-|:|;|\*|\?|"|\'|<|>|\_|\.|\?', ' ', title).lower()    title = ' '.join(title.split())    return title    
class source:
    domains = ['watchfree.movie']
    name = 'watchfree'
    sources = [] 

    def __init__(self):        self.priority = 1                self.language = ['en']        self.domains = ['ddlvalley.me']        self.sources2=[]        
        self.scraper = cfscrape.create_scraper() # self.scraper.get
        self.base_link = 'https://www.watchfree.movie'
        self.search = '/search.html?keyword='

# =======================================================================================================================================    def movie(self, imdb, title, localtitle, aliases, year):        return title+'$$$$'+year+'$$$$'+imdb+'$$$$movie'
    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):        return imdb+'$$$$'+ tvdb+'$$$$'+ tvshowtitle+'$$$$'+ localtvshowtitle+'$$$$'+ year    def episode(self, url, imdb, tvdb, title, premiered, season, episode):        data=url.split('$$$$')        title=data[2]        return title+'$$$$'+imdb+'$$$$'+ tvdb+'$$$$'+ title+'$$$$'+ premiered+'$$$$'+ season+'$$$$'+ episode+'$$$$tv'    def sources(self, url, hostDict, hostprDict):
          debrid = debrid_s.status()          data=url.split('$$$$')          if data[3]=='movie':                                                        title=data[0]            year=data[1]            imdb=data[2]            debrid = debrid_s.status()
            search_id = clean_search(title.lower())
            start_url = '%s%s%s' %(self.base_link,self.search,search_id.replace(' ','+'))
            #print 'Start URL >>> '+start_url
            
            headers = {'User-Agent':User_Agent}
            OPEN = requests.get(start_url,headers=headers,timeout=10).content
            Regex = re.compile('<figure>.+?href="(.+?)"',re.DOTALL).findall(OPEN)
            for item_url in Regex:
                item_url=self.base_link+item_url
                OPEN2 = requests.get(item_url,headers=headers,timeout=10).content
                Regex2 = re.compile('class="detail-r".+?>(.+?)</div>.+?Release: (.+?)</div>',re.DOTALL).findall(OPEN2)
                for name,release in Regex2:
                    name = checker.name_clean(name)
                    name=name.split('(')[0]
                    #print 'Link >>> '+item_url
                    #print 'Name >>> '+name
                    #print 'Year >>> '+release
                    if not year == release:
                        continue
                    if clean_title(search_id).lower() == clean_title(name).lower():
                        #print 'Sent Movie To Source >>> ' + item_url + '\n'
                        self.get_source(item_url,title,year,'','',debrid)
            return self.sources2          else:                                title=data[0]                show_year=data[4]                year=data[4]                show_year=year                season=data[5]                episode=data[6]                imdb=data[1]                tvdb=data[2]
                search_id = clean_search(title.lower())                                start_url = '%s%s%s' %(self.base_link,self.search,search_id.replace(' ','+'))                #print 'Start URL >>> '+start_url                headers = {'User-Agent':User_Agent}                OPEN = requests.get(start_url,headers=headers,timeout=10).content                Regex = re.compile('<figure>.+?<a href="(.+?)".+?<img alt="(.+?)".+?title="(.+?)"',re.DOTALL).findall(OPEN)                for item_url,name,seas in Regex:                    name = checker.name_clean(name)                    name=name.split('-')[0]                    seas=seas.split('-')[-1]                    seas=seas.replace('Season ','').replace(' ','')                    item_url = self.base_link+item_url                    #print 'Link >>> '+item_url                    #print 'Name >>> '+name                    #print 'Season >>> '+seas                    if not clean_title(title).lower() == clean_title(name).lower():                        continue                    if not season == seas:                        continue                    #print '=== Episode Sent To Second Page ==='                    headers = {'User-Agent':User_Agent}                    OPEN2 = requests.get(item_url,headers=headers,timeout=10).content                    Regex2 = re.compile('<li.+?<a href="(.+?)">.+?title="(.+?)"',re.DOTALL).findall(OPEN2)                    for item_url,epis in Regex2:                        item_url = self.base_link+item_url                        epis=epis.replace(' ','')                        epis=epis.split('Episode')[-1].split('-')[0].split(':')[0]                        #print 'Link >>> '+item_url                        #print 'Episode >>> '+epis                        if not episode == epis:                            continue                        #print 'Sent Episode To Source >>> ' + item_url + '\n'                        self.get_source(item_url,title,year,season,episode,debrid)                return self.sources2

# =======================================================================================================================================


            
# =======================================================================================================================================

    def get_source(self, item_url, title, year, season, episode, debrid):
       
            #debrid = True # REMOVE BEFORE USING SCRAPER IN KODI
            debrid = debrid_s.status()
            headers = {'User-Agent':User_Agent}
            OPEN = requests.get(item_url,headers=headers,timeout=10).content
            quality = re.compile('<span class="quanlity">(.+?)</span>',re.DOTALL).findall(OPEN)
            for quality in quality:
                check_quality = checker.check_quality(quality)

            headers = {'User-Agent':User_Agent}
            OPEN = requests.get(item_url,headers=headers,timeout=10).content
            Regex = re.compile('var link_server.+?"(.+?)"',re.DOTALL).findall(OPEN)
            for link in Regex:
                if 'http' not in link:
                    link = 'http:'+link
                if 'http' in link and '//' in link:					
                        if debrid is False:
                            host = link.split('//')[1].replace('www.','').split('.')[0].lower()
                            check_site = checker.check_site(host)
                            if 'Resolve' in check_site:
                                hostname = link.split('//')[1].replace('www.','').split('/')[0].split('.')[0].title()
                                self.sources2.append({'source': hostname,'language': 'en', 'quality': check_quality, 'scraper': self.name, 'url': link, 'direct': False, 'debridonly': False})
                                #print '%s | %s | %s | \n'%(link,check_quality,'Resolve')
                        elif debrid is True:                            logging.warning(link)
                            host = link.split('//')[1].replace('www.','').split('.')[0].lower()
                            check_site = checker.check_site(host)
                            if 'Resolve' in check_site:
                                hostname = link.split('//')[1].replace('www.','').split('/')[0].split('.')[0].title()
                                self.sources2.append({'source': hostname,'language': 'en', 'quality': check_quality, 'scraper': self.name, 'url': link, 'direct': False, 'debridonly': False})
                                #print '%s | %s | %s | \n'%(link,check_quality,'Resolve')
                            elif 'Debrid' in check_site:
                                hostname = link.split('//')[1].replace('www.','').split('/')[0].split('.')[0].title()
                                self.sources2.append({'source': hostname,'language': 'en', 'quality': check_quality, 'scraper': self.name, 'url': link, 'direct': False, 'debridonly': True})
                                #print '%s | %s | %s | \n'%(link,check_quality,'Debrid')
     
    def resolve(self, url):        return url
# =======================================================================================================================================

#Scraper12().scrape_movie('Rampage','2018','') # REMOVE BEFORE USING SCRAPER IN KODI
#Scraper12().scrape_episode('Ozark','','','1','1','','') # REMOVE BEFORE USING SCRAPER IN KODI