# -*- coding: utf-8 -*-
# Universal Scrapers checked 30/8/2018

import re
import urllib,logging
import xbmc, xbmcaddon, time

from resources.lib.universalscrapers.common import clean_title
from resources.lib.universalscrapers.modules import client
     

def clean_search(title):

    if title == None: return
    title = title.lower()
    title = re.sub('&#(\d+);', '', title)
    title = re.sub('(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
    title = title.replace('&quot;', '\"').replace('&amp;', '&')
    title = re.sub('\\\|/|\(|\)|\[|\]|\{|\}|-|:|;|\*|\?|"|\'|<|>|\_|\.|\?', ' ', title).lower()
    title = ' '.join(title.split())
    return title

class source:
    domains = ['https://movie4u.ch']
    name = "movie4u"
    sources = []

    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.base_link = 'https://movie4u.live'
        self.sources2=[]
    def movie(self, imdb, title, localtitle, aliases, year):
        return title+'$$$$'+year+'$$$$'+imdb+'$$$$movie'
    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        return imdb+'$$$$'+ tvdb+'$$$$'+ tvshowtitle+'$$$$'+ localtvshowtitle+'$$$$'+ year
    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        data=url.split('$$$$')
        title=data[2]
        
        return title+'$$$$'+imdb+'$$$$'+ tvdb+'$$$$'+ title+'$$$$'+ premiered+'$$$$'+ season+'$$$$'+ episode+'$$$$tv'
    def sources(self, url, hostDict, hostprDict):
       data=url.split('$$$$')
       title=data[0]
       year=data[1]
       imdb=data[2]
       if data[3]=='movie':
    
        try:
            start_time = time.time()
            search_id = clean_search(title.lower())
            start_url = '%s/?s=%s' % (self.base_link, urllib.quote_plus(search_id))
            headers = {'User-Agent': client.agent()}
            html = client.request(start_url, headers=headers)
            posts = client.parseDOM(html, 'div', attrs={'class': 'result-item'})
            posts = [(client.parseDOM(i, 'div', attrs={'class': 'details'})[0]) for i in posts if i]
            posts = [i for i in posts if not 'SEO Checker' in i]
            for post in posts:
                try:
                    name = client.parseDOM(post, 'a')[0]
                    url = client.parseDOM(post, 'a', ret='href')[0]
                    date = client.parseDOM(post, 'span', attrs={'class': 'year'})[0]
                except:
                    raise Exception()
                name = re.sub('<.+?>', '', name)
                tit = re.sub('(\.|\(|\[|\s)(\d{4}|S\d+E\d+|S\d+)(\.|\)|\]|\s|)(.+|)', '', name, flags=re.I)

                if not clean_title(title) == clean_title(tit):
                    continue
                if not year == date:
                    continue
                self.get_source(url, title, year, '', '', start_time)
            
            return self.sources2
        except Exception, argument:        
            
            return self.sources2
       else:
        data=url.split('$$$$')
        
        title=data[0]
        show_year=data[4]
        year=data[4]
        season=data[5]
        episode=data[6]
        imdb=data[1]
        tvdb=data[2]
   
        if 1:#try:
            logging.warning('INTV')
            start_time = time.time()
            search_id = clean_search(title.lower())
            start_url = '%s/?s=%s+season+%s' % (self.base_link, urllib.quote_plus(search_id), season)
            headers = {'User_Agent': client.agent()}
            html = client.request(start_url, headers=headers)
            #print 'PAGE>>>>>>>>>>>>>>>>>'+html
            posts = client.parseDOM(html, 'div', attrs={'class': 'result-item'})
            posts = [(client.parseDOM(i, 'div', attrs={'class': 'details'})[0]) for i in posts if i]
            posts = [i for i in posts if not 'SEO Checker' in i]
            for post in posts:
                try:
                    name = client.parseDOM(post, 'a')[0]
                    name = re.sub('<.+?>', '', name)
                    url = client.parseDOM(post, 'a', ret='href')[0]
                except:
                    raise Exception()
                tit = re.sub('(\.|\(|\[|\s)(Season)(\.|\)|\]|\s|)(.+|)', '', name, flags=re.I)
                if not clean_title(title).lower() == clean_title(tit).lower():
                    continue

                epi_id = '%sx%s/' % (season, episode)
                ep_link = url.replace('/seasons/', '/episodes/')
                ep_link = ep_link.split('-season')[0] + '-%s' % epi_id

                self.get_source(ep_link, title, year, season, episode, start_time)
                
            #print self.sources
            return self.sources2
        #except Exception, argument:        
            
        #    return self.sources2
            
    def get_source(self,url,title,year,season,episode,start_time):
        try:
            headers = {'User-Agent': client.agent()}
            OPEN = client.request(url, headers=headers)
            holder = client.parseDOM(OPEN, 'div', attrs={'class':'bwa-content'})[0]
            holder = client.parseDOM(holder, 'a', ret='href')[0]
            links = client.request(holder, headers=headers)
            Regex = client.parseDOM(links, 'iframe', ret='src', attrs={'class': 'metaframe rptss'})
            count = 0
            for link in Regex:
                if 'player.php' in link:
                    link = client.request(link, headers=headers, output='geturl')
                    qual = client.request(link, headers=headers)
                    qual = client.parseDOM(qual, 'meta', ret='content')[0]
                else:
                    link = link

                host = link.split('//')[1].replace('www.','')
                host = host.split('/')[0].split('.')[0].title()

                if '1080p' in qual:
                    rez = '1080p'
                elif '720p' in qual:
                    rez = '720p'
                else: rez = 'SD'
                count += 1
                self.sources2.append({'source': host, 'quality': rez,'language': 'en', 'url': link, 'direct': False, 'debridonly': False})
            
        except:
            pass
    def resolve(self, url):
        return url
#movie4u().scrape_movie('Wonder Woman', '2017','')
#movie4u().scrape_episode('Suits','2011','','8','5','','')